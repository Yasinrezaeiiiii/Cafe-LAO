package cafe.sms

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        web = WebView(this)
        web.setBackgroundColor(0xFF070B11.toInt())
        window.statusBarColor = 0xFF070B11.toInt()
        window.navigationBarColor = 0xFF070B11.toInt()
        web.fitsSystemWindows = true
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setSupportZoom(false)
        web.settings.builtInZoomControls = false
        web.settings.displayZoomControls = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.SEND_SMS), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(function(){var s=document.getElementById('sheet');if(s.classList.contains('on')){closeSheet();return 1}return 0})()") {
            if (it != "1") finish()
        }
    }

    @Suppress("DEPRECATION")
    private fun sms(): SmsManager =
        if (android.os.Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun report(id: String, ok: Int, fail: Int, total: Int) = runOnUiThread {
        web.evaluateJavascript("window.onSmsProgress('$id',$ok,$fail,$total)", null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun sendBatch(id: String, json: String, delayMs: Int) {
            Thread {
                val arr = JSONArray(json)
                val total = arr.length()
                var ok = 0
                var fail = 0
                val allowed = checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
                for (i in 0 until total) {
                    val o = arr.getJSONObject(i)
                    try {
                        if (!allowed) throw SecurityException()
                        val m = sms()
                        m.sendMultipartTextMessage(o.getString("phone"), null, m.divideMessage(o.getString("text")), null, null)
                        ok++
                    } catch (e: Exception) { fail++ }
                    report(id, ok, fail, total)
                    if (i < total - 1) Thread.sleep(delayMs.toLong().coerceAtLeast(1000))
                }
            }.start()
        }

        @JavascriptInterface
        fun share(name: String, text: String) = runOnUiThread {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, name)
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(i, name))
        }
    }
}
